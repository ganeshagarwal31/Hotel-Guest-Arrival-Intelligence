import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import Notification from "../components/Notification";
import { useState } from "react";

function RoomsPage() {

  const [message, setMessage] = useState("");

  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState("");
  const [customerName, setCustomerName] = useState("");
const [customerEmail, setCustomerEmail] = useState("");
const [customerPhone, setCustomerPhone] = useState("");

  const [showRooms, setShowRooms] = useState(false);
  const [booking, setBooking] = useState(
  JSON.parse(localStorage.getItem("booking"))
);

  const defaultRooms = [

  // Standard Rooms
  {
    id: 101,
    name: "Standard Room 101",
    image: "https://images.unsplash.com/photo-1566665797739-1674de7a421a",
    price: "₹2500",
    size: "250 Sq.ft",
    guests: "2 Guests",
    bed: "Queen Bed",
    available: true
  },
  {
    id: 102,
    name: "Standard Room 102",
    image: "https://images.unsplash.com/photo-1566665797739-1674de7a421a",
    price: "₹2500",
    size: "250 Sq.ft",
    guests: "2 Guests",
    bed: "Queen Bed",
    available: true
  },
  {
    id: 103,
    name: "Standard Room 103",
    image: "https://images.unsplash.com/photo-1566665797739-1674de7a421a",
    price: "₹2500",
    size: "250 Sq.ft",
    guests: "2 Guests",
    bed: "Queen Bed",
    available: true
  },

  // Deluxe Rooms
  {
    id: 201,
    name: "Deluxe Room 201",
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b",
    price: "₹4500",
    size: "350 Sq.ft",
    guests: "3 Guests",
    bed: "King Bed",
    available: true
  },
  {
    id: 202,
    name: "Deluxe Room 202",
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b",
    price: "₹4500",
    size: "350 Sq.ft",
    guests: "3 Guests",
    bed: "King Bed",
    available: true
  },
  {
    id: 203,
    name: "Deluxe Room 203",
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b",
    price: "₹4500",
    size: "350 Sq.ft",
    guests: "3 Guests",
    bed: "King Bed",
    available: true
  },

  // Family Rooms
  {
    id: 301,
    name: "Family Room 301",
    image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39",
    price: "₹7000",
    size: "500 Sq.ft",
    guests: "5 Guests",
    bed: "2 Queen Beds",
    available: true
  },
  {
    id: 302,
    name: "Family Room 302",
    image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39",
    price: "₹7000",
    size: "500 Sq.ft",
    guests: "5 Guests",
    bed: "2 Queen Beds",
    available: true
  },
  {
    id: 303,
    name: "Family Room 303",
    image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39",
    price: "₹7000",
    size: "500 Sq.ft",
    guests: "5 Guests",
    bed: "2 Queen Beds",
    available: true
  },

  // Luxury Suites
  {
    id: 401,
    name: "Luxury Suite 401",
    image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461",
    price: "₹8000",
    size: "600 Sq.ft",
    guests: "4 Guests",
    bed: "King Bed",
    available: true
  },
  {
    id: 402,
    name: "Luxury Suite 402",
    image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461",
    price: "₹8000",
    size: "600 Sq.ft",
    guests: "4 Guests",
    bed: "King Bed",
    available: true
  },
  {
    id: 403,
    name: "Luxury Suite 403",
    image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461",
    price: "₹8000",
    size: "600 Sq.ft",
    guests: "4 Guests",
    bed: "King Bed",
    available: true
  },

  // Presidential Suites
  {
    id: 501,
    name: "Presidential Suite 501",
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304",
    price: "₹15000",
    size: "1000 Sq.ft",
    guests: "6 Guests",
    bed: "Luxury King Bed",
    available: true
  },
  {
    id: 502,
    name: "Presidential Suite 502",
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304",
    price: "₹15000",
    size: "1000 Sq.ft",
    guests: "6 Guests",
    bed: "Luxury King Bed",
    available: true
  },
  {
    id: 503,
    name: "Presidential Suite 503",
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304",
    price: "₹15000",
    size: "1000 Sq.ft",
    guests: "6 Guests",
    bed: "Luxury King Bed",
    available: true
  }
];
const [roomsData, setRoomsData] = useState(() => {

  const savedRooms =
    localStorage.getItem("rooms");

  return savedRooms
    ? JSON.parse(savedRooms)
    : defaultRooms;

});

  const handleSearch = () => {

    if (
  customerName === "" ||
  customerEmail === "" ||
  customerPhone === "" ||
  checkIn === "" ||
  checkOut === "" ||
  guests === ""
){

      setMessage(
        "Please fill all booking details."
      );

      setTimeout(() => {
        setMessage("");
      }, 3000);

      return;
    }

    setShowRooms(true);
  };

 const handleBooking = (roomId) => {

  const updatedRooms =
    roomsData.map((room) =>

      room.id === roomId
        ? {
            ...room,
            available: false
          }
        : room
    );

  setRoomsData(updatedRooms);

  localStorage.setItem(
  "rooms",
  JSON.stringify(updatedRooms)
);
const bookedRoom =
  updatedRooms.find(
    room => room.id === roomId
  );

const bookingData = {
  ...bookedRoom,
  customerName,
  customerEmail,
  customerPhone,
  checkIn,
  checkOut
};

setBooking(bookingData);
const existingBookings =
  JSON.parse(
    localStorage.getItem("bookings")
  ) || [];

const updatedBookings = [
  ...existingBookings,
  bookingData
];

localStorage.setItem(
  "bookings",
  JSON.stringify(updatedBookings)
);
  setMessage(
    bookedRoom.name +
    " Booked Successfully!"
  );

  setTimeout(() => {
    setMessage("");
  }, 3000);
};
const handleCancelBooking = () => {

  if (!booking) return;

  const updatedRooms = roomsData.map((room) =>

    room.id === booking.id
      ? {
          ...room,
          available: true
        }
      : room
  );

  setRoomsData(updatedRooms);
  setShowRooms(true);

  localStorage.setItem(
    "rooms",
    JSON.stringify(updatedRooms)
  );

  localStorage.removeItem("booking");

  setBooking(null);

  setMessage(
    "Booking Cancelled Successfully!"
  );

  setTimeout(() => {
    setMessage("");
  }, 3000);
};

  return (

    <>
      <Navbar />

      <Notification message={message} />

      <section className="page-section">

        <h1>Room Availability</h1>

        <p className="page-subtitle">
          Search and book your perfect stay
        </p>

        {/* Booking Form */}

        <div className="booking-bar">
          <div className="booking-field">
  <label>Full Name</label>

  <input
    type="text"
    placeholder="Enter Full Name"
    value={customerName}
    onChange={(e) =>
      setCustomerName(e.target.value)
    }
  />
</div>
<div className="booking-field">
  <label>Email</label>

  <input
    type="email"
    placeholder="Enter Email"
    value={customerEmail}
    onChange={(e) =>
      setCustomerEmail(e.target.value)
    }
  />
</div>
<div className="booking-field">
  <label>Mobile Number</label>

  <input
    type="tel"
    placeholder="Enter Mobile Number"
    value={customerPhone}
    onChange={(e) =>
      setCustomerPhone(e.target.value)
    }
  />
</div>

          <div className="booking-field">
            <label>Check In</label>

            <input
              type="date"
              value={checkIn}
              onChange={(e) =>
                setCheckIn(e.target.value)
              }
            />
          </div>

          <div className="booking-field">
            <label>Check Out</label>

            <input
              type="date"
              value={checkOut}
              onChange={(e) =>
                setCheckOut(e.target.value)
              }
            />
          </div>

          <div className="booking-field">
            <label>Guests</label>

            <select
              value={guests}
              onChange={(e) =>
                setGuests(e.target.value)
              }
            >
              <option value="">
                Select
              </option>

              <option value="1">
                1 Guest
              </option>

              <option value="2">
                2 Guests
              </option>

              <option value="3">
                3 Guests
              </option>

              <option value="4">
                4 Guests
              </option>

              <option value="5">
                5 Guests
              </option>
            </select>
          </div>

          <button
            className="search-btn"
            onClick={handleSearch}
          >
            Search Availability
          </button>

        </div>

        {/* Available Rooms */}
{booking && (

  <div className="room-card">

    <h2>My Booking</h2>

    <br />

    <p>
      <strong>Room:</strong>
      {" "}
      {booking.name}
    </p>

    <p>
      <strong>Price:</strong>
      {" "}
      {booking.price}
    </p>

    <p>
      <strong>Size:</strong>
      {" "}
      {booking.size}
    </p>

    <br />

    <button
      onClick={handleCancelBooking}
    >
      Cancel Booking
    </button>

  </div>

)}
        {showRooms && (

  <div className="availability-section">

    <h2>Available Rooms</h2>

    <div className="rooms-page-grid">

      {roomsData
  .filter(room => room.available)
  .map((room) => (

        <div
          key={room.id}
          className="room-card"
        >

          <img
            src={room.image}
            alt={room.name}
            className="room-image"
          />

          <h2>{room.name}</h2>

          <p>{room.size}</p>

          <p>{room.guests}</p>

          <p>{room.bed}</p>

          <h3>{room.price} / Night</h3>

          <button
            onClick={() =>
  handleBooking(room.id)
}
          >
            Book Now
          </button>

        </div>

      ))}

    </div>

  </div>

)}

      </section>

      <Footer />
    </>
  );
}

export default RoomsPage;