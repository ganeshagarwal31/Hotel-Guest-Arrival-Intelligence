import { useState } from "react";
import { useNavigate } from "react-router-dom";

function AdminDashboard() {

  const navigate = useNavigate();

  const [roomName, setRoomName] =
    useState("");

  const [roomPrice, setRoomPrice] =
    useState("");

  const [rooms, setRooms] =
    useState(
      JSON.parse(
        localStorage.getItem("rooms")
      ) || []
    );

  const bookings =
    JSON.parse(
      localStorage.getItem("bookings")
    ) || [];

  const bookedRooms =
    bookings.length;

  const availableRooms =
    rooms.length - bookedRooms;

  const handleAddRoom = () => {

    const newRoom = {
      id: Date.now(),
      name: roomName,
      price: roomPrice,
      size: "300 Sq.ft",
      guests: "2 Guests",
      bed: "Queen Bed",
      image:
        "https://images.unsplash.com/photo-1566665797739-1674de7a421a",
      available: true
    };

    const updatedRooms = [
      ...rooms,
      newRoom
    ];

    setRooms(updatedRooms);

    localStorage.setItem(
      "rooms",
      JSON.stringify(updatedRooms)
    );

    setRoomName("");
    setRoomPrice("");
  };

  const handleDeleteRoom = (id) => {

    const updatedRooms =
      rooms.filter(
        room => room.id !== id
      );

    setRooms(updatedRooms);

    localStorage.setItem(
      "rooms",
      JSON.stringify(updatedRooms)
    );
  };

  return (

    <div className="admin-container">

      <h1>Hotel Admin Dashboard</h1>

      <div className="admin-stats">

        <div className="stat-card">
          <h2>{rooms.length}</h2>
          <p>Total Rooms</p>
        </div>

        <div className="stat-card">
          <h2>{bookedRooms}</h2>
          <p>Booked Rooms</p>
        </div>

        <div className="stat-card">
          <h2>{availableRooms}</h2>
          <p>Available Rooms</p>
        </div>

      </div>

      <div className="admin-actions">

        <button
          onClick={() =>
            navigate("/booked-rooms")
          }
        >
          View Booked Rooms
        </button>

        <button
          onClick={() =>
            navigate("/available-rooms")
          }
        >
          View Available Rooms
        </button>

      </div>

      <hr />

      <h2
        style={{
          color:"#fff",
          marginBottom:"20px"
        }}
      >
        Add New Room
      </h2>

      <input
        type="text"
        placeholder="Room Name"
        value={roomName}
        onChange={(e)=>
          setRoomName(e.target.value)
        }
      />

      <input
        type="text"
        placeholder="Price"
        value={roomPrice}
        onChange={(e)=>
          setRoomPrice(e.target.value)
        }
      />

      <button
        onClick={handleAddRoom}
      >
        Add Room
      </button>

      <hr
        style={{
          margin:"30px 0"
        }}
      />

      <h2
        style={{
          color:"#fff",
          marginBottom:"20px"
        }}
      >
        Manage Rooms
      </h2>

      {rooms.map((room)=>(

        <div
          key={room.id}
          className="admin-card"
        >

          <h3>{room.name}</h3>

          <p>
            Price: {room.price}
          </p>

          <button
            onClick={() =>
              handleDeleteRoom(room.id)
            }
          >
            Remove Room
          </button>

        </div>

      ))}

    </div>
  );
}

export default AdminDashboard;