import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Notification from "../components/Notification";

function Login() {

  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = () => {

    const savedUser = JSON.parse(localStorage.getItem("user"));

    if (
      savedUser &&
      savedUser.email === email &&
      savedUser.password === password
    ) {

      localStorage.setItem("isLoggedIn", true);

      setMessage("Login Successful!");

      setTimeout(() => {
        navigate("/");
      }, 1500);

    } else {

      setMessage("Invalid Email or Password");
    }
  };

  return (
    <div className="form-container">

      <Notification message={message} />

      <div className="form-box">

        <h1>Welcome Back</h1>

        <p>
          Login to continue your luxury stay experience
        </p>

        <input
          type="email"
          placeholder="Enter Email"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleLogin}>
          Login
        </button>

      </div>

    </div>
  );
}

export default Login;