import { useState } from "react";
import { useNavigate } from "react-router-dom";

import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import Rooms from "../components/Rooms";
import Facilities from "../components/Facilities";
import About from "../components/About";
import Footer from "../components/Footer";
import Notification from "../components/Notification";

function Home() {

  const navigate = useNavigate();

  const [bookedRoom, setBookedRoom] = useState(
    localStorage.getItem("bookedRoom")
  );

  const [message, setMessage] = useState("");

  const user = JSON.parse(
    localStorage.getItem("user")
  );
const handleBooking = (roomName) => {
  console.log("BOOK BUTTON CLICKED", roomName);
  
  console.log("handleBooking running");

  const bookingData = {
    id: Date.now(),
    name: roomName
  };

  const existingBookings =
    JSON.parse(
      localStorage.getItem("bookings")
    ) || [];

  const updatedBookings = [
    ...existingBookings,
    bookingData
  ];

  localStorage.setItem(
    "bookings",
    JSON.stringify(updatedBookings)
  );

  localStorage.setItem(
    "bookedRoom",
    roomName
  );

  setBookedRoom(roomName);

  setMessage(
    roomName + " Booked Successfully!"
  );

  setTimeout(() => {
    setMessage("");
  }, 3000);
};

  const handleLogout = () => {

    localStorage.removeItem(
      "isLoggedIn"
    );

    navigate("/login");
  };

  return (

    <div className="home-page">

      {/* Notification */}
      <Notification message={message} />

      {/* NAVBAR */}
      <Navbar />

      {/* HERO */}
      <Hero />
      <section className="booking-bar">

  <div className="booking-field">
    <label>Check In</label>
    <input type="date" />
  </div>

  <div className="booking-field">
    <label>Check Out</label>
    <input type="date" />
  </div>

  <div className="booking-field">
    <label>Guests</label>

    <select>
      <option>1 Guest</option>
      <option>2 Guests</option>
      <option>3 Guests</option>
      <option>4 Guests</option>
      <option>5 Guests</option>
    </select>
  </div>

  <div className="booking-field">
    <label>Rooms</label>

    <select>
      <option>1 Room</option>
      <option>2 Rooms</option>
      <option>3 Rooms</option>
    </select>
  </div>
  
<button
  className="search-btn"
  onClick={() => navigate("/rooms")}
>
  Search Availability
</button>

</section>

      {/* USER INFO */}
      {user && (

        <div className="user-info">

          <h3>
            Welcome, {user.name}
          </h3>

        </div>

      )}

      {/* BOOKED ROOM */}
      {bookedRoom && (

        <div className="booked-room">

          <h3>
            Your Booked Room: {bookedRoom}
          </h3>

        </div>

      )}

      {/* ROOMS */}
      <Rooms
        handleBooking={handleBooking}
      />

      {/* FACILITIES */}
      <Facilities />

      {/* ABOUT */}
      <About />

      {/* GALLERY */}
      <section
        className="gallery"
        id="gallery"
      >

        <h2>
          Hotel Gallery
        </h2>

        <div className="gallery-grid">

          <img
            src="https://images.unsplash.com/photo-1566073771259-6a8506099945"
            alt="Hotel"
          />

          <img
            src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b"
            alt="Room"
          />

          <img
            src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461"
            alt="Pool"
          />

        </div>

      </section>

      {/* LOGOUT */}
      <div className="logout-section">

        <button
          className="gold-btn"
          onClick={handleLogout}
        >
          Logout
        </button>

      </div>

      {/* FOOTER */}
      <Footer />

    </div>

  );
}

export default Home;