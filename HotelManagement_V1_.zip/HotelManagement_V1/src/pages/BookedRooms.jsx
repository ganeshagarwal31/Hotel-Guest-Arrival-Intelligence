function BookedRooms() {

  const bookings =
    JSON.parse(
      localStorage.getItem("bookings")
    ) || [];

  return (

    <div className="admin-page">
<button
  onClick={() =>
    window.history.back()
  }
>
  Back
</button>
      <h1>Booked Rooms</h1>

      {bookings.map((booking,index)=>(

        <div
          key={index}
          className="admin-card booked"
        >

          <h3>{booking.name}</h3>

          <p>{booking.customerName}</p>

          <p>{booking.checkIn}</p>

          <p>{booking.checkOut}</p>

        </div>

      ))}

    </div>
  );
}

export default BookedRooms;