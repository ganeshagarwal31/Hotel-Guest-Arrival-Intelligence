import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function ContactPage() {

  return (

    <>
      <Navbar />

      <section className="page-section">

        <h1>Contact Us</h1>

        <div className="room-card">

          <h2>Hotel Paradise</h2>

          <p>Marine Drive, Mumbai</p>

          <p>+91 9876543210</p>

          <p>info@hotelparadise.com</p>

        </div>

      </section>

      <Footer />
    </>
  );
}

export default ContactPage;