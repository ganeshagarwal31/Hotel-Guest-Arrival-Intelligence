function AvailableRooms() {

  const rooms =
    JSON.parse(
      localStorage.getItem("rooms")
    ) || [];

  const bookings =
    JSON.parse(
      localStorage.getItem("bookings")
    ) || [];

  const availableRooms =
    rooms.filter(
      room =>
        !bookings.some(
          booking =>
            booking.id === room.id
        )
    );

  return (

    <div className="admin-page">
<button
  onClick={() =>
    window.history.back()
  }
>
  Back
</button>
      <h1>Available Rooms</h1>

      {availableRooms.map((room)=>(

        <div
          key={room.id}
          className="admin-card available"
        >

          <h3>{room.name}</h3>

          <p>{room.price}</p>

        </div>

      ))}

    </div>
  );
}

export default AvailableRooms;