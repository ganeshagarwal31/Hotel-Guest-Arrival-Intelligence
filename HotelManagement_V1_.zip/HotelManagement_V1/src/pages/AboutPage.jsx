import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function AboutPage() {

  return (

    <>
      <Navbar />

      <section className="page-section">

        <h1>About Hotel Paradise</h1>

        <div className="room-card">

          <h2>Our Story</h2>

          <p>
            Established in 2015, Hotel Paradise
            offers luxury hospitality and world-class
            guest experiences.
          </p>

          <br />

          <h2>Statistics</h2>

          <p>120 Luxury Rooms</p>
          <p>80 Staff Members</p>
          <p>50,00s0+ Happy Guests</p>
          <p>35+ Countries Served</p>
          <p>4.8 ★ Rating</p>

        </div>

      </section>

      <Footer />
    </>
  );
}

export default AboutPage;