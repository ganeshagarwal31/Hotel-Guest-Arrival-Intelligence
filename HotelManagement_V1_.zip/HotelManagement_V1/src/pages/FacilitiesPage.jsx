import { useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function FacilitiesPage() {
  const [activeIndex, setActiveIndex] = useState(null);

  const facilities = [
    {
      name: "Swimming Pool",
      img: "https://images.unsplash.com/photo-1500375592092-40eb2168fd21",
      info: "Relax in our clean and temperature-controlled swimming pool.",
      timing: "6:00 AM - 10:00 PM",
    },
    {
      name: "Gym",
      img: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48",
      info: "Fully equipped fitness center with modern machines.",
      timing: "5:00 AM - 11:00 PM",
    },
    {
      name: "Restaurant",
      img: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4",
      info: "Multi-cuisine dining with buffet and à la carte options.",
      timing: "Breakfast, Lunch & Dinner available",
    },
    {
      name: "Spa & Wellness",
      img: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874",
      info: "Luxury spa services for relaxation and rejuvenation.",
      timing: "9:00 AM - 8:00 PM",
    },
    {
      name: "Parking",
      img: "https://images.unsplash.com/photo-1506521781263-d8422e82f27a",
      info: "Secure and spacious 24x7 parking facility.",
      timing: "24 x 7 Available",
    },
    {
      name: "Room Service",
      img: "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba",
      info: "Quick in-room dining and assistance anytime.",
      timing: "24 x 7 Available",
    },
  ];

  return (
    <>
      <Navbar />

      <section className="page-section">
        <h1>Hotel Facilities</h1>

        <div className="rooms-page-grid">
          {facilities.map((item, index) => (
            <div
              className="room-card"
              key={index}
              onClick={() =>
                setActiveIndex(activeIndex === index ? null : index)
              }
              style={{ cursor: "pointer" }}
            >
              <img
                src={item.img}
                alt={item.name}
                style={{
                  width: "100%",
                  height: "180px",
                  objectFit: "cover",
                  borderRadius: "10px",
                }}
              />

              <h2>{item.name}</h2>

              <p><b>Timing:</b> {item.timing}</p>

              {activeIndex === index && (
                <div className="extra-info">
                  <p>{item.info}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </>
  );
}

export default FacilitiesPage;