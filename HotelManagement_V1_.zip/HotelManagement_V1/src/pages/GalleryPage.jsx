import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function GalleryPage() {

  return (

    <>
      <Navbar />

      <section className="page-section">

        <h1>Hotel Gallery</h1>

        <div className="gallery-grid">

  <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945" alt="1" />
  <img src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b" alt="2" />
  <img src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461" alt="3" />
  <img src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb" alt="4" />
  <img src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85" alt="5" />
  <img src="https://images.unsplash.com/photo-1445019980597-93fa8acb246c" alt="6" />
  <img src="https://images.unsplash.com/photo-1455587734955-081b22074882" alt="7" />
  <img src="https://images.unsplash.com/photo-1618773928121-c32242e63f39" alt="8" />
  <img src="https://images.unsplash.com/photo-1590490360182-c33d57733427" alt="9" />
  <img src="https://images.unsplash.com/photo-1631049307264-da0ec9d70304" alt="10" />

  <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945" alt="11" />
  <img src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b" alt="12" />
  <img src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461" alt="13" />
  <img src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb" alt="14" />
  <img src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85" alt="15" />
  <img src="https://images.unsplash.com/photo-1445019980597-93fa8acb246c" alt="16" />
  <img src="https://images.unsplash.com/photo-1455587734955-081b22074882" alt="17" />
  <img src="https://images.unsplash.com/photo-1618773928121-c32242e63f39" alt="18" />
  <img src="https://images.unsplash.com/photo-1590490360182-c33d57733427" alt="19" />
  <img src="https://images.unsplash.com/photo-1631049307264-da0ec9d70304" alt="20" />

</div>

      </section>

      <Footer />
    </>
  );
}

export default GalleryPage;