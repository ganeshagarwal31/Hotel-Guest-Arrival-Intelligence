function Rooms({ handleBooking }) {

  return (

    <section className="rooms" id="rooms">

      <div className="room-card">

        <h3>Deluxe AC Room</h3>

        <h2>₹4500</h2>

        <p>/ night</p>

        <button
          onClick={() =>
            handleBooking("Deluxe AC Room")
          }
        >
          Book Room
        </button>

      </div>

      <div className="room-card">

        <h3>Luxury Suite</h3>

        <h2>₹8000</h2>

        <p>/ night</p>

        <button
          onClick={() =>
            handleBooking("Luxury Suite")
          }
        >
          Book Room
        </button>

      </div>

      <div className="room-card">

        <h3>Standard Room</h3>

        <h2>₹2500</h2>

        <p>/ night</p>

        <button
          onClick={() =>
            handleBooking("Standard Room")
          }
        >
          Book Room
        </button>

      </div>

    </section>
  );
}

export default Rooms;