function Facilities() {
  return (

    <section
      className="facilities"
      id="facilities"
    >

      <div>AC Rooms</div>

      <div>Swimming Pool</div>

      <div>Restaurant</div>

      <div>24/7 Support</div>

      <div>Free WiFi</div>

      <div>Parking Area</div>

    </section>
  );
}

export default Facilities;