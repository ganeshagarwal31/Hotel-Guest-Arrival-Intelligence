function Hero() {
  return (
    <section className="hero" id="hero">

      <p className="hero-tag">
        WELCOME TO
      </p>

      <h1>
        Hotel Paradise
      </h1>

      <p className="hero-text">
        Experience luxury, comfort and world-class
        hospitality like never before.
      </p>

      <div className="hero-buttons">

        <button className="gold-btn">
          Explore Rooms
        </button>

        <button className="outline-btn">
          View Facilities
        </button>

      </div>

    </section>
  );
}

export default Hero;