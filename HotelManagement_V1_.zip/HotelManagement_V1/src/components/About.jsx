function About() {

  return (

    <section
      className="about"
      id="about"
    >

      <div className="about-text">

        <p className="gold-text">
          WELCOME TO PARADISE
        </p>

        <h2>
          Where Comfort
          Meets Elegance
        </h2>

        <p>
          At Hotel Paradise, we blend modern luxury
          with warm hospitality to create unforgettable
          experiences.
        </p>

        <button className="gold-btn">
          About Us
        </button>

      </div>

      <div className="about-image">

        <img
          src="https://images.unsplash.com/photo-1566073771259-6a8506099945"
          alt="Hotel"
        />

      </div>

    </section>
  );
}

export default About;