function Footer() {

  return (

    <footer
      className="footer"
      id="footer"
    >

      <div>

        <h2>HOTEL PARADISE</h2>

        <p>
          Experience luxury,
          comfort and unforgettable moments.
        </p>

      </div>

      <div>

        <h3>Quick Links</h3>

        <p>Home</p>
        <p>Rooms</p>
        <p>Facilities</p>
        <p>Gallery</p>

      </div>

      <div>

        <h3>Facilities</h3>

        <p>Swimming Pool</p>
        <p>Restaurant</p>
        <p>Free WiFi</p>

      </div>

      <div>

        <h3>Contact Us</h3>

        <p>+91 98765 43210</p>

        <p>info@hotelparadise.com</p>

      </div>

    </footer>
  );
}

export default Footer;