import "./App.css";

import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

import RoomsPage from "./pages/RoomsPage";
import FacilitiesPage from "./pages/FacilitiesPage";
import AboutPage from "./pages/AboutPage";
import GalleryPage from "./pages/GalleryPage";
import ContactPage from "./pages/ContactPage";

import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";
import BookedRooms from "./pages/BookedRooms";
import AvailableRooms from "./pages/AvailableRooms";

import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  return (
    <BrowserRouter>

      <Routes>

        <Route path="/" element={<Home />} />

        <Route path="/rooms" element={<RoomsPage />} />

        <Route path="/facilities" element={<FacilitiesPage />} />

        <Route path="/about" element={<AboutPage />} />

        <Route path="/gallery" element={<GalleryPage />} />

        <Route path="/contact" element={<ContactPage />} />

        <Route path="/login" element={<Login />} />

        <Route path="/signup" element={<Signup />} />

        <Route path="/admin-login" element={<AdminLogin />} />

        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/booked-rooms"
          element={
            <ProtectedRoute>
              <BookedRooms />
            </ProtectedRoute>
          }
        />

        <Route
          path="/available-rooms"
          element={
            <ProtectedRoute>
              <AvailableRooms />
            </ProtectedRoute>
          }
        />

      </Routes>

    </BrowserRouter>
  );
}

export default App;